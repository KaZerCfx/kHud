fx_version 'adamant'

game 'gta5'
author 'KaZer#9999'

ui_page 'html/ui.html'

client_scripts {
	'client/cl_hud.lua'
}

files {
	'html/ui.html',
	'html/kazer/style.css',
	'html/kazer/main.js',
	'html/kazer/bouf.png',
	'html/kazer/eau.png',
}
